import React from 'react'

export default function Button({handleAddition}) {
    return (
        
        <div className=" row d-flex justify-content-center align-content-center">
          <button className="btn btn-danger w-25" onClick = {handleAddition}>Sum</button>
       </div>
    )
  
}