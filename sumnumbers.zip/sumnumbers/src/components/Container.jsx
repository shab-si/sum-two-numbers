import  React from 'react'
import Header from './Header'
import Formsum from './Formsum'

export default function Container() {
     
   

    return (
        
        <div className="container mt-5">
            <Header />
        
            <div>
                    <Formsum placeholder1="Number 1" placeholder2="Number 2" />  
                    
                  
                
                
            </div>


        </div>


    )

 }