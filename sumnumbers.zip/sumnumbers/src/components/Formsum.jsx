import React, { useState } from 'react';
import Button from './Button';

function InputComponent({ placeholder1, placeholder2 }) {
  const [number1, setNumber1] = useState(0);
  const [number2, setNumber2] = useState(0);
  const [result, setResult] = useState(0);

  const handleNumber1Change = (event) => {
    setNumber1(Number(event.target.value));
  };

  const handleNumber2Change = (event) => {
    setNumber2(Number(event.target.value));
  };

  const handleAddition = () => {
    setResult(number1 + number2);
  };

  return (
    <div> 
        <div class="mb-3 mt-3 text-center row d-flex justify-content-center">
            <input type="number" className="form-control rounded-0 w-50" placeholder={placeholder1} onChange={handleNumber1Change} />
        </div>
        <div class="mb-3 text-center row d-flex justify-content-center">
             <input type="number" className="form-control rounded-0 w-50" placeholder={placeholder2} onChange={handleNumber2Change} />
        </div>
      
      
      <Button handleAddition={handleAddition} />
      <p>Result: {result}</p>
    </div>
  );
}

export default InputComponent;

