import React from 'react'

export default function Header() {
    return (
       
        <div>
            <h3 className="text-center mt-2">Enter your numbers</h3>
        </div>

    )

}