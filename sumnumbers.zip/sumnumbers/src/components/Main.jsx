import React from 'react';
import './style.css';
import Container from './Container';


export default function Main(){
    
    
  
      return (
        <>   
           < Container />
        </>
       )
     } 
  
  